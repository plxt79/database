-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1493640)
addappid(1493641, 1, "326c7fa2a40d5873408cd1acf39a170f5fa5bfe71400e373310c48f5f154923c")
setManifestid(1493641, "485036796624936746", 0)