-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1206560)
addappid(1206561, 1, "cba01e9f6c75a6b26fe978e7179476176b3a191358379fcd3727d4fdaef5d2b6")
setManifestid(1206561, "7056392980458818047", 0)