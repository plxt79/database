-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2280)
addappid(2281, 1, "59d59862ea40c92ef01e270e60c349de893eee7a55a089cb6ef63b68e8935075")
setManifestid(2281, "4669188166801166499", 0)