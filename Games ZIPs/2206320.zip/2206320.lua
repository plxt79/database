-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(2206320)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"5087715316087945828")
addappid(2206321,0,"01b1ee5730664096c3d70ed486a4147f426f4c5f2d6501225d4707120c598f43")
setManifestid(2206321,"1520703224969502260")