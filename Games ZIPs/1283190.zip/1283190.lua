-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1283190)
addappid(1283191,0,"c482a5a6304d7f7d3df9a771f629969364f0c0019ce2c646d92ababfbf04b889")
setManifestid(1283191,"322240771317091078")