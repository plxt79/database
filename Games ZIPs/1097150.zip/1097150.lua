--actual game

addappid(1097150)
addappid(1097151, 1, "243e7ffcd6bbd15f3976f648f7d851f975219f7a995ffb32e404e7a94e84dae9")
setManifestid(1097151, "4296583284325860558", 0)

--dlc

addappid(1261620)
addappid(1343612)
addappid(1362660)
addappid(1426910)
addappid(1481570)
addappid(1532290)
addappid(1569400)
addappid(1570380)
addappid(1570390)
addappid(1622930)
addappid(1677990)
addappid(1677991)