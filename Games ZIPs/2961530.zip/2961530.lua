-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2961530)
addappid(2961531, 1, "dff8b76588bfbefe7aceedf3312c31c7eab25b590d1a95485d82bad8d4ba225b")
setManifestid(2961531, "2577502915854789086", 0)