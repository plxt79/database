-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2506160)
addappid(2506161, 1, "21ca9f80277ec51e1e063ad48d39eb22f37081c9034ab900704dde1986b4806e")
setManifestid(2506161, "8875520618792936983", 0)