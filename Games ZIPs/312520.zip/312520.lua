--actual game

addappid(312520)
addappid(312521, 1, "f36b23dfaca5b387508e33fe17732bcd48a16ab0fef3b1eb819494ad76d5ce2a")
setManifestid(312521, "918503140736468559", 0)

--dlc
addappid(1933390)
addappid(2857120)