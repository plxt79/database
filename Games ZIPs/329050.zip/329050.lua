--game

addappid(329050)
addappid(329051, 1, "4da524a16eb2bb8577d094a37394176b10de35a42d6bcdecdd5c5115a324f2f3")
setManifestid(329051, "7950608430955718471", 0)
addappid(329052, 1, "8c64bb7a4690a8c03abdbdd37d6b8f2facd53e84b65bee01f5fc4ba7cbf820c4")
setManifestid(329052, "1243308987442157279", 0)

--dlc

addappid(359490)
addappid(359491)
addappid(359492)
addappid(359493)
addappid(359494)
addappid(359495)
addappid(359497)