-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2120900)
addappid(2120901, 1, "b060afd33253ced6be83479f4afbcaf0e174a108c185c3ce5c6c106e0aaaabc3")
setManifestid(2120901, "7788332384184121782", 0)