-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1721470)
addappid(1721471, 1, "d8ffbaae7dda98a1608af24916982826d6ec61a8a1338fda6f793da5d3239152")
setManifestid(1721471, "1791252873090904500", 0)
addappid(1721472, 1, "9ff882ee821997013c8a26b12ee0e04fe781434ec5e6d41881ec53c759bacdd0")
setManifestid(1721472, "258245258388090593", 0)

-- dlc
addappid(1817490) -- Poppy Playtime - Chapter 2
addappid(1817491, 1, "e8a0b69343b9b3297a7db08e084898fd14130435cf9b95a9e77b794a430e66a0")
setManifestid(1817491, "6474053569987505700", 0)
addappid(2555190) -- Poppy Playtime - Chapter 3
addappid(2555198, 1, "9b728f6de496b74d3e277f9e8dd3c852dd0b70b4ab461fc5c2d5db73a5ffeec2")
setManifestid(2555198, "7976244025258826224", 0)
addappid(3008670, 1, "05af48230917e5f7df38d99935306907947f276d13191bc0853a0338fc295fa7") -- Poppy Playtime - Chapter 4
setManifestid(3008670, "1278777716171617955", 0)