-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(33130)
addappid(33131,0,"9d10e5ea033dbf88acb8a171faae5810f2bfbc02ff064c4b97dee1c37d17e860")
setManifestid(33131,"3193489821000094733")
addappid(33132,0,"01e18fa4a915d88e61817b331008136d62712db01e5ca74c9226d65bb18fde5a")
setManifestid(33132,"8370043962024163531")