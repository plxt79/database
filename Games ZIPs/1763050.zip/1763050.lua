-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1763050)
addappid(1763051, 1, "5506e30e0f825869abc207dee41bc99b82c73ca6939272e56149077f80618421")
setManifestid(1763051, "3854526276740594378", 0)