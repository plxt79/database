--game

addappid(997010)
addappid(997011, 1, "788e33ebc2e38174d9b613b57ed47947aacaf7399a6bbd32762161e56ce34d62")
setManifestid(997011, "4047140644961127472", 0)

--dlc

addappid(2009550)
addappid(2199030)
addappid(2210960)
addappid(2350410)
addappid(2513250)
addappid(2527820)
addappid(2527830)
addappid(2893870)
addappid(2893880)
addappid(3048950)
addappid(3167630)