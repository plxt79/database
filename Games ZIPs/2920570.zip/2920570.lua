-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(2920570)
addappid(2920571, 1, "2936fe6bebf97616a1cbb0e4aa41393c5483773bec5053130418999c4126485e")
setManifestid(2920571, "1747338637349860759", 0)