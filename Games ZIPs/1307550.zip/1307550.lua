-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1307550)
addappid(1307551, 1, "12f11842a788e0b656032cfbaf79b2ee2e74e3f7715e25ddd2efe5c0a33afc35")
setManifestid(1307551, "296887556937689961", 0)